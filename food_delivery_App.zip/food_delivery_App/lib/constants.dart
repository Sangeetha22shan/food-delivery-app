const String appName = "Zomato";
const String slogan = "Delivery App";
const String bgImage = "images/food.jpg";
const String login = "Login";
