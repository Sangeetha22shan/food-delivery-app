import 'package:flutter/material.dart';

const Color primaryColor = Color(0xff08c105);
